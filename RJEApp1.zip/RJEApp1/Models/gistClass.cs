﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace RJEApp1
{
    public class gistClass
    {
        public class gist
        {
            public string url { get; set; }
            public string forks_url { get; set; }
            public string commits_url { get; set; }
            public string id { get; set; }
            public string git_pull_url { get; set; }
            public string git_push_url { get; set; }
            public string html_url { get; set; }
            //public gistfiles[] gistfile;
            public gistfiles[] gistfile { get; set; }
            //public JObject gistfiles { get; set; }
            public gistowner gistowner { get; set; }
            public bool gpublic { get; set; }
            public string created_at { get; set; }
            public string updated_at { get; set; }
            public string description { get; set; }
            public string comments { get; set; }
            public string user;
            public string comments_url;
            public bool truncated { get; set; }
        }

        public class gistfiles
        {
            public string gist { get; set; }
            public string filename { get; set; }
            public string type { get; set; }
            public string language { get; set; }
            public string raw_url { get; set; }
            public string size { get; set; }
        }

        public class gistfile
        {
            public string filename { get; set; }
            public string type { get; set; }
            public string language { get; set; }
            public string raw_url { get; set; }
            public string size { get; set; }
        }

        public class gistowner
        {
            public string login { get; set; }
            public string id { get; set; }
            public string avatar_url { get; set; }
            public string gravatar_id { get; set; }
            public string url { get; set; }                 //ownurl
            public string ownhtml_url { get; set; }         // ownhtml_url
            public string followers_url { get; set; }
            public string following_url { get; set; }
            public string gists_url { get; set; }
            public string starred_url { get; set; }
            public string subscriptions_url { get; set; }
            public string organizations_url { get; set; }
            public string repos_url { get; set; }
            public string events_url { get; set; }
            public string received_events_url { get; set; }
            public string type { get; set; }                //owntype
            public bool site_admin { get; set; }

        }

        public class gistlist
        {
            public string filename { get; set; }
            public string type { get; set; }
            public string language { get; set; }
            public string raw_url { get; set; }
            public string size { get; set; }
            public string description { get; set; }
            public string login { get; set; }
        }

    }
    
}