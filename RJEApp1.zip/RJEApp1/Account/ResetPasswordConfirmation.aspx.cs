﻿using System.Web.UI;

namespace RJEApp1.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}