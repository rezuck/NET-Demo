﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace RJEApp1
{
    public class JSONUtilities  : JSONClass
    {
        public void JSONSerialize()
        {
            //to do
        }

        override public void DeserialJSON(string inVal)
        {

        }

        override public string prepareJSON(string json)
        {
            //Initialize some vars
            string vFile = "";

            //Get the lkist of gist files

            List<string> gfiles = WebData.gistList(json);

            //Clean up some errant characters
            json = json.Replace("\r", "");
            json = json.Replace("\n", "");
            json = json.Replace(@"files"":{", @"gistfile"":[");
            json = json.Replace("owner", "gistowner");
            json = json.Replace(@"},""public", @"],""gpublic");
            json = json.Substring(1, json.Length - 2);

            //Convert the dynamicobjects into an array
            foreach (string o in gfiles)
            {
                vFile = @"""" + o + @""":";
                json = json.Replace(vFile, "");
            }

            //Return the clean json
            return json;
        }

        override public JObject jObj(string json)
        {
            //This function converts json to a JSON.NET object

            //Initialize some vars
            string prepjson = "";
            JSONUtilities util = new JSONUtilities();

            prepjson = util.prepareJSON(json);
            JObject outObj = JObject.Parse(prepjson);

            return outObj;

        }

        public override List<gistClass.gistlist> fetchGistList(string json)
        {
            //This function produces a list of gist files from the raw json.
            //It parses the json and extracts the gist file information and places it in an
            //Entity Framework like list.

            //We could create a JSON object (jObject) and process it. We choose this approach
            //to demonstrate our parsing skills. Sometimes you just have to get your hands dirty.

            //Here we set some variables.
            List<gistClass.gistlist> gistList = new List<gistClass.gistlist>();
            int start = 0;
            int iend = 0;
            string filename = "";
            string raw_url = "";
            string desc = "";
            string login = "";

            try
            {
                int lngth = 0;
                while (iend <= json.Length - 1 & (iend != -1 & start != -1))
                {
                    //First we get the filename
                    start = json.IndexOf(@"{""filename"":""", iend + 2);
                    iend = json.IndexOf("type", iend + 2);
                    gistClass.gistlist g = new gistClass.gistlist();
                    if (iend - start < 0)
                    {
                        iend = json.IndexOf("type", iend + 2);
                    }
                    lngth = iend - start - 13;
                    if ((start != -1 & iend != -1) && lngth > 3)
                    {
                        filename = json.Substring(start + 13, lngth - 3);
                        g.filename = filename;
                    }

                    //We get the raw_url. This will allow us to get the full text file from GitHub.
                    start = json.IndexOf(@"""raw_url"":", iend);
                    iend = json.IndexOf(@",""size"":", iend);
                    lngth = iend - start - 11;
                    if ((start != -1 & iend != -1) && lngth > 1)
                    {
                        raw_url = json.Substring(start + 11, lngth - 1);
                        g.raw_url = raw_url;
                    }

                    //We get the description the creator of the file entered. We will display this
                    // in our list.
                    start = json.IndexOf(@"""description"":", iend);
                    iend = json.IndexOf(@"""comments"":", start);
                    lngth = iend - start - 13;
                    if ((start != -1 & iend != -1) && lngth > 4)
                    {
                        desc = json.Substring(start + 15, lngth - 4);
                        g.description = desc;
                    }

                    //Here we get the user. Although we don't display it, we still
                    //get it in case we want it later.
                    start = json.IndexOf(@"{""login"":", iend);
                    iend = json.IndexOf(@",""id"":", start);
                    lngth = iend - start - 8;
                    if ((start != -1 & iend != -1) && lngth > 4)
                    {
                        login = json.Substring(start + 11, lngth - 4);
                        g.login = login;
                   }

                    gistList.Add(g);

                }

                return gistList;
            }
            catch (Exception e)
            {
                //if there is an error, we end up here.
                return gistList;
            }
        }
    }
}