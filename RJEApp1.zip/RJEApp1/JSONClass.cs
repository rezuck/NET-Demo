﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace RJEApp1
{
    abstract public class JSONClass
    {
        public JSONClass()
        {
            // Code to initialize the class goes here.
        }

        abstract public void DeserialJSON(string inVal);
        abstract public string prepareJSON(string json);
        abstract public JObject jObj(string json);
        abstract public List<gistClass.gistlist> fetchGistList(string json);

    }
}